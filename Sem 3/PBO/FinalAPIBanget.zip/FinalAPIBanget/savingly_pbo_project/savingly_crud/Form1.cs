﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using MySql.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
using table_counter;
using System.Windows.Forms.DataVisualization.Charting;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;

namespace savingly_crud
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }


        /// <summary>
        /// Function to Insert data <br/>
        /// </summary>
        /// <exception cref="System.ArgumentOutOfRangeException">Thrown when spending is null or less than 0</exception>
        private void button_insert_Click(object sender, EventArgs e)
        {
            MySqlConnection conn;
            MySqlCommand cmd;
            mt_connect_db(out conn, out cmd, "insert into SPENDING(date,spending,items) values (@date,@spending,@items)");
            mt_parameter_addvalue(cmd, "@date", date_picker.Value);


            try
            {
                if (int.Parse(textbox_spending.Text) >= 0)
                {
                    mt_parameter_addvalue(cmd, "@spending", int.Parse(textbox_spending.Text));
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
            catch
            {
                MessageBox.Show("Insert Unsuccessfull!");
            }
            mt_parameter_addvalue(cmd, "@items", textbox_items.Text);
            cmd.ExecuteNonQuery();
            conn.Close();
            mt_message("Added");
        }

        /// <summary>
        /// Function to Update data <br/>
        /// </summary>
        /// <exception cref="System.ArgumentOutOfRangeException">Thrown when ...</exception>
        private void button_update_Click(object sender, EventArgs e)
        {
            MySqlConnection conn;
            MySqlCommand cmd_update;
            mt_connect_db(out conn, out cmd_update, "Update SPENDING set spending=@spending, items=@items where ID=@ID");
            MySqlCommand cmd_refresh = new MySqlCommand("Select * from SPENDING", conn);
            // TEST ID ada pada tabel dan tidak boleh < 1
            mt_show_table(cmd_refresh, table);
            try
            {
                int i;
                for (i = 0; i < table.Rows.Count; i++)
                {

                }
                if (int.Parse(textbox_ID_updel.Text) <= i-1)
                {
                    if (int.Parse(textbox_ID_updel.Text) <= 0)
                    {
                        throw new ArgumentOutOfRangeException();
                    }
                    else
                    {
                        mt_parameter_addvalue(cmd_update, "@ID", int.Parse(textbox_ID_updel.Text));

                    }
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
                // TEST nilai uang apakah negatif.
                if (int.Parse(textbox_spending_updel.Text) >= 0)
                {
                    mt_parameter_addvalue(cmd_update, "@spending", int.Parse(textbox_spending_updel.Text));
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
                mt_parameter_addvalue(cmd_update, "@items", textbox_items_updel.Text);

                cmd_update.ExecuteNonQuery();
                conn.Close();
                mt_message("Updated");
            }
            catch
            {
                MessageBox.Show("Update Unsuccessfull!");
            }
        }


        private void button_delete_Click(object sender, EventArgs e)
        {
            //MySqlConnection conn = new MySqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|Savingly_DB.mdf\";Integrated Security=True;Connect Timeout=30");
            MySqlConnection conn = new MySqlConnection("Server=sql6.freesqldatabase.com;Database=sql6586173;Uid=sql6586173;Pwd=Mh9Mzklu2a;Port=3306");
            //memindahkan data ke SPENDING_BU
            try
            {
                // Delete SPENDING
                MySqlCommand cmd_refresh = new MySqlCommand("Select * from SPENDING", conn);
                // TEST ID ada pada tabel dan tidak boleh < 1
                mt_show_table(cmd_refresh, table);

                conn.Open();
                MySqlCommand cmd_delete = new MySqlCommand("DELETE FROM `SPENDING` WHERE `SPENDING`.`ID` = @ID", conn);
                int i;
                for (i = 0; i < table.Rows.Count; i++)
                {

                }
                if (int.Parse(textbox_ID_updel.Text) <= i - 1)
                {
                    if (int.Parse(textbox_ID_updel.Text) <= 0)
                    {
                        throw new ArgumentOutOfRangeException();
                    }
                    else
                    {
                        cmd_delete.Parameters.AddWithValue("@ID", int.Parse(textbox_ID_updel.Text));

                    }
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
                
                cmd_delete.ExecuteNonQuery();

                // Transfer SPENDING --> SPENDING BU

                MySqlCommand cmd_backup = new MySqlCommand("INSERT INTO `SPENDING_BU` (`date`,`spending`, `items`) SELECT `date`,`spending`,`items` FROM `SPENDING`;", conn);
                cmd_backup.ExecuteNonQuery();

                // Reseed SPENDING

                MySqlCommand cmd_reseed_SPENDING = new MySqlCommand("TRUNCATE TABLE SPENDING; alter table SPENDING auto_increment = 1;", conn);
                cmd_reseed_SPENDING.ExecuteNonQuery();

                //// Transfer SPENDING_BU --> SPENDING

                MySqlCommand cmd_restore = new MySqlCommand("INSERT INTO `SPENDING` (`date`,`spending`, `items`) SELECT `date`,`spending`,`items` FROM `SPENDING_BU`;", conn);
                cmd_restore.ExecuteNonQuery();

                // Reseed SPENDING_BU

                MySqlCommand cmd_reseed_SPENDING_BU = new MySqlCommand("TRUNCATE TABLE SPENDING_BU; alter table SPENDING auto_increment = 1;", conn);
                cmd_reseed_SPENDING_BU.ExecuteNonQuery();

                conn.Close();

                mt_message("Deleted");
            }
            catch
            {
                MessageBox.Show("Delete Unsuccessfull!");
            }
        }

        private void button_refresh_Click(object sender, EventArgs e)
        {
            MySqlConnection conn;
            MySqlCommand cmd_refresh;
            mt_connect_db(out conn, out cmd_refresh,  "Select * from SPENDING");
            mt_show_table(cmd_refresh, table);
            mt_read_table(table);
        }



        private void button_spending_Click(object sender, EventArgs e)
        {
            MySqlConnection conn;
            MySqlCommand command;
            mt_connect_db(out conn, out command,  "Select * from SPENDING where date between @fromdate and @todate");
            mt_parameter_addvalue(command, "@fromdate", date_picker_from_date.Value);
            mt_parameter_addvalue(command, "@todate", date_picker_to_date.Value);
            mt_show_table(command, table_between_date);
            table_sum mt = new table_sum();
            mt.mt_total_spending(textbox_total_spending_output, table_between_date, 2);

        }

        /// <summary>
        /// Method to show message after an action is done 
        /// </summary>
        /// <param name="action">Action to Add, Update, or Delete a data</param>
        private static void mt_message(string action)
        {
            MessageBox.Show($"Successfully {action}!");
        }

        /// <summary>
        /// Method to open connection to a localDB.
        /// <example>
        /// For example:
        /// <code>
        /// mt_connect_db(out conn, out cmd, "database_DB.mdf", "Select * from SPENDING")
        /// </code>
        /// </example>
        /// </summary>
        /// <param name="conn">SqlConnection instance</param>
        /// <param name="cmd">SqlCommand instance</param>
        /// <param name="local_db">file database name in bin/debug</param>
        /// <param name="sql_command">Command to Insert, Update, or delete a data</param>
        //private static void mt_connect_db(out SqlConnection conn, out SqlCommand cmd, string sql_command)
        private static void mt_connect_db(out MySqlConnection conn, out MySqlCommand cmd, string sql_command)
        {
            //conn = new SqlConnection($"Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|{local_db}\";Integrated Security=True;Connect Timeout=30");
            conn = new MySqlConnection("Server=sql6.freesqldatabase.com;Database=sql6586173;Uid=sql6586173;Pwd=Mh9Mzklu2a;Port=3306");
            conn.Open();
            cmd = new MySqlCommand(sql_command, conn);
        }

        private void mt_show_table(MySqlCommand cmd_refresh, DataGridView table_name)
        {
            MySqlDataAdapter da = new MySqlDataAdapter(cmd_refresh);
            DataTable dt = new DataTable();
            da.Fill(dt);
            table_name.DataSource = dt;
        }



        /// <value>Property <c>X</c> represents the point's x-coordinate.</value>
        private void mt_parameter_addvalue(MySqlCommand command, string data_holder, object data_value)
        {
            command.Parameters.AddWithValue(data_holder, data_value);
        }

        private void table_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void table_between_date_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button_chart_Click(object sender, EventArgs e)
        {

            MySqlConnection conn;
            MySqlCommand cmd;
            mt_connect_db(out conn, out cmd, "SELECT (YEAR(date) * 100) + MONTH(date) AS date, sum(spending) as spending FROM SPENDING GROUP BY (YEAR(date) * 100) + MONTH(date) order by date;");
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            table.DataSource = dt;
            chart.DataSource = dt;
            chart.Series[0].XValueMember = "date";
            chart.Series[0].YValueMembers = "spending";
            chart.DataBind();
        }

        public void mt_read_table(DataGridView table_name)
        {
            DataTable dt = new DataTable();

            return;
        }
    }
}