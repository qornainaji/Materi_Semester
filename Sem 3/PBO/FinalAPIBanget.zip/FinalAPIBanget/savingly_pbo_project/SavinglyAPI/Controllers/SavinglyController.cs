﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SavinglyAPI.Models;
using System.Data;
using System.Windows.Forms;
using System.Data;
using System;
using MySql.Data.MySqlClient;



namespace SavinglyAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SavinglyController : ControllerBase
    {
        public readonly IConfiguration _configuration;
        public SavinglyController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetSavingly")]
        public string GetSavingly()
        {

            MySqlConnection conn = new MySqlConnection(_configuration.GetConnectionString("SavinglyAppConn"));
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM SPENDING", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            List<Savingly> savingly_list = new List<Savingly>();
            Response response = new Response();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Savingly savingly = new Savingly();
                    savingly.id = Convert.ToString(dt.Rows[i]["ID"]);
                    savingly.date = Convert.ToString(dt.Rows[i]["date"]);
                    savingly.spending = Convert.ToString(dt.Rows[i]["date"]);
                    savingly.items = Convert.ToString(dt.Rows[i]["items"]);
                    savingly_list.Add(savingly);

                }

            }

            if (savingly_list.Count > 0)
            {
                return JsonConvert.SerializeObject(savingly_list);
            }
            else
            {
                response.StatusCode = 100;
                response.ErrorMessage = "No data found";
                return JsonConvert.SerializeObject(response);
            }

        }
    }
}
