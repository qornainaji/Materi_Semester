﻿using System;
using System.Windows.Forms;

namespace table_counter
{
    public class table_sum
    {
        public void mt_total_spending(TextBox textbox, DataGridView table_name, int cell_index)
        {
            textbox.Text = "0";
            for (int i = 0; i < table_name.Rows.Count; i++)
            {
                if (table_name.Rows[i].Cells[cell_index].Value == null)
                {
                    table_name.Rows[i].Cells[cell_index].Value = 0;
                }
                textbox.Text = Convert.ToString(int.Parse(textbox.Text) + int.Parse(table_name.Rows[i].Cells[cell_index].Value.ToString()));
            }
        }
    }
}
