﻿namespace SavinglyAPI.Models
{
    public class Savingly
    {
        public string id { get; set; }
        public string date { get; set; }
        public string spending { get; set; }
        public string items { get; set; }
    }
}

