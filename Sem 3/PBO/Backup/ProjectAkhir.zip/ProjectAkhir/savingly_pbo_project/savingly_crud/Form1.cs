﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.CodeDom.Compiler;

namespace savingly_crud
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textbox_spending_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_insert_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|Savingly_DB.mdf\";Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into SPENDING values (@date,@spending,@items)", conn);
            cmd.Parameters.AddWithValue("@date", date_picker.Value);
            cmd.Parameters.AddWithValue("@spending", int.Parse(textbox_spending.Text));
            cmd.Parameters.AddWithValue("@items", textbox_items.Text);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Spending successfully've been recorded.");
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|Savingly_DB.mdf\";Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd_update = new SqlCommand("Update SPENDING set spending=@spending, items=@items where ID=@ID", conn);
            cmd_update.Parameters.AddWithValue("@ID", int.Parse(textbox_ID_updel.Text));
            cmd_update.Parameters.AddWithValue("@spending", int.Parse(textbox_spending_updel.Text));
            cmd_update.Parameters.AddWithValue("@items", textbox_items_updel.Text);
            cmd_update.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Update spending is successfully've been done.");
        }

        private void text_date_Click(object sender, EventArgs e)
        {

        }

        private void date_picker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|Savingly_DB.mdf\";Integrated Security=True;Connect Timeout=30");

            try //memindahkan data ke SPENDING_BU
            {
                    // Delete SPENDING

                conn.Open();
                SqlCommand cmd_delete = new SqlCommand("Delete SPENDING where ID=@ID", conn);
                cmd_delete.Parameters.AddWithValue("@ID", int.Parse(textbox_ID_updel.Text));
                cmd_delete.ExecuteNonQuery();

                    // Reseed SPENDING_BU
               
                SqlCommand cmd_reseed_SPENDING_BU = new SqlCommand("DBCC CHECKIDENT ('SPENDING_BU', RESEED, 0) ", conn);
                cmd_reseed_SPENDING_BU.ExecuteNonQuery();
                
                    // Transfer SPENDING --> SPENDING BU
               
                SqlCommand cmd_backup = new SqlCommand("Insert Into SPENDING_BU(date,spending,items) select date,spending,items from SPENDING", conn);
                cmd_backup.ExecuteNonQuery();
                
                    // Delete all SPENDING
                
                SqlCommand cmd_delete_all = new SqlCommand("DELETE FROM SPENDING", conn);
                cmd_delete_all.ExecuteNonQuery();
                
                    // Reseed SPENDING
                
                SqlCommand cmd_reseed_SPENDING = new SqlCommand("DBCC CHECKIDENT ('SPENDING', RESEED, 0) ", conn);
                cmd_reseed_SPENDING.ExecuteNonQuery();
                
                    // Transfer SPENDING_BU --> SPENDING
                
                SqlCommand cmd_restore = new SqlCommand("Insert Into SPENDING(date,spending,items) select date,spending,items from SPENDING_BU", conn);
                cmd_restore.ExecuteNonQuery();
                
                    // Delete all SPENDING_BU
                
                SqlCommand cmd_delete_BU_all = new SqlCommand("DELETE FROM SPENDING_BU", conn);
                cmd_delete_BU_all.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Delete Success!");
            }
            catch
            {
                MessageBox.Show("Delete UNsuccessfull!");
            }
        }

        private void button_refresh_Click(object sender, EventArgs e)
            {
                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|Savingly_DB.mdf\";Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand cmd_refresh = new SqlCommand("Select * from SPENDING", conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd_refresh);
                DataTable dt = new DataTable();
                da.Fill(dt);
                table.DataSource = dt;
            }
    }
    
}




