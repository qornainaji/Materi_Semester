//Test Program personType
 
#include "Controller.h"
 
using namespace std;

int main()
{

    Controller controller; 
    controller.commandLoop();

    return 0;
}


