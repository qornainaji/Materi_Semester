/**
 * Project Person Register Application
 */


#ifndef _CONTROLLER_H
#define _CONTROLLER_H

class Controller
{
public:
    void commandLoop();
    void registerPerson();
    void viewCurrentPerson();
    void viewPreviousPerson();
    void viewNextPerson();
};

#endif //_CONTROLLER_H